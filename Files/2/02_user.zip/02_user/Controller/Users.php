<?php

namespace Controller;

class Users
{
	public function register()
	{
		if ($_SERVER['REQUEST_METHOD'] == 'GET') {
			render('user/register_form', []);
			return;
		}

		$password = password_hash($_POST['password'], PASSWORD_BCRYPT, ['cost' => 12]);

		global $db;
		$stmt = $db->prepare("insert into user (id, login, password) values (?, ?, ?)");
		$stmt->bindParam(2, $_POST['login'], \PDO::PARAM_STR);
		$stmt->bindParam(3, $password, \PDO::PARAM_STR);
		$stmt->execute();
	}

	public function login()
	{
		if ($_SERVER['REQUEST_METHOD'] == 'GET') {
			render('user/login_form', []);
			return;
		}

		global $db;
		$stmt = $db->prepare("select * from user where login = ?");
		$stmt->bindParam(1, $_POST['login'], \PDO::PARAM_STR);
		$stmt->execute();
		$user = $stmt->fetch();
		if (password_verify($_POST['password'], $user['password'])) {
			// CONNECTED
		} else {
			// WRONG PASSWORD
		}
	}

	public function list()
	{
		global $db;
		$stmt = $db->prepare("select * from user");
		if ($stmt->execute() === false) {
			echo $stmt->errorCode();
			return;
		}
		$users = $stmt->fetchAll();
		render('user/list', $users);
	}
}
