<?php

return [
	'database' => [
		'path' => 'database.sqlite',
	],
];
