<h1>Article</h1>
<p><?= $data ?></p>
