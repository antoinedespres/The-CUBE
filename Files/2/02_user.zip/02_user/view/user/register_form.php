<form method="POST">
	<input type="text" name="login">
	<input type="password" name="password">
	<input type="submit">
</form>
